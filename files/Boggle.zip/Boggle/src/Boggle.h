/*
* file: boggle.h
* ---------------------
* author: Nahva Techlu and Jeremy Bao
* date: Nov. 6
* This is the header file for the Boggle class, which declares the
* public and private variables / functions in the Boggle class.
*/

#ifndef _boggle_h
#define _boggle_h

#include <iostream>
#include <string>
#include "lexicon.h"
#include "Grid.h"

using namespace std;

class Boggle {
public:
    Boggle(Lexicon& dictionary, string boardText = "");
    char getLetter(int row, int col);
    bool checkWord(string word);
    bool humanWordSearch(string word);
    Set<string> computerWordSearch();
    int getScoreHuman();
    int getScoreComputer();
    friend ostream& operator<<(ostream& out, Boggle& boggle);
    Set<string> outputHumanFoundWords();

private:
    //Variables
    Grid<char> gameBoard;
    Set<string> usedWords;
    Set<string> humanFoundWords;
    Set<string> computerFoundWords;
    Set<int> checkedLetters;
    Set<int> checkedLetters2;
    Lexicon dict;
    string wordForCheck;
    int humanScore = 0;
    int computerScore = 0;
    string curWord;

    //Fuctions
    bool recursiveCheck(string &wordCheck, int r, int c);
    void recursiveComputerCheck(int r, int c);

};

#endif // _boggle_h
