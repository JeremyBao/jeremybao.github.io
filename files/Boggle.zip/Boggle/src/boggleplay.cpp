/*
* file: boggleplay.cpp
* ---------------------
* author: Nahva Techlu and Jeremy Bao
* date: Nov. 6
* This is the file that executes the boggle game. It will refer
* to the Boggle class to achieve plenty of functions in the game.
* It also has its own functions, including asking the users to input
* the board, input words, judging who wins, etc.
*/

#include "lexicon.h"
#include "simpio.h"
#include <cctype>
#include <string>
#include "Boggle.h"
#include "bogglegui.h"
#include "console.h"

using namespace std;
using namespace BoggleGUI;

//Self-defined functions
bool userSelectBoard (string &boardText);
bool userInputWord(Boggle& newBoggle, string &newWord);

void playOneGame(Lexicon& dictionary) {
    initialize(4, 4);
    reset();
    string boardText = "";
    string newWord = "";
    int humanScore = 0;
    int computerScore  = 0;
    userSelectBoard(boardText);
    Boggle newBoggle(dictionary, boardText);

    //Putting all the letters to the GUI
    for (int r = 0; r < 4; r++){
        for (int c = 0; c < 4; c++){
            labelCube(r, c, newBoggle.getLetter(r, c), false);
        }
    }

    // User's turn of the game
    clearConsole();
    cout<<"It's your turn!"<<endl;
    cout<<newBoggle<<endl;

    while (true){
        bool continueOrNot = userInputWord(newBoggle, newWord); //let user input a word and check whether the word is valid
        if (continueOrNot){
            if (newBoggle.humanWordSearch(newWord)){
                clearConsole();
                cout<<"You found a new word! \""<<newWord<<"\""<<endl;
                cout<<newBoggle<<endl;
                cout<<"Your words ("<<newBoggle.outputHumanFoundWords().size()<<"): "<<newBoggle.outputHumanFoundWords()<<endl;
                humanScore = newBoggle.getScoreHuman();
                cout<<"Your score: "<<humanScore<<endl;
                setScore(humanScore, BoggleGUI::HUMAN);
                setStatusMessage("You found a new word! \"" + newWord + "\"");
                recordWord(newWord, BoggleGUI::HUMAN);
            }
        } else {
            break;
        }
    }

    // Computer's turn of the game
    cout<<"It's my turn!"<<endl;
    Set<string> wordsFound = newBoggle.computerWordSearch();
    cout<<"My words ("<<wordsFound.size()<<"): "<<wordsFound<<endl;
    computerScore = newBoggle.getScoreComputer();
    cout<<"My score: "<<computerScore<<endl;
    setScore(computerScore, BoggleGUI::COMPUTER);
    for (string eachWord : wordsFound){
        recordWord(eachWord, BoggleGUI::COMPUTER);
    }

    //Judging who wins
    if (computerScore > humanScore)
    {
        cout<<"Ha ha ha, I destroyed you. Better luck next time, puny human!"<<endl;
        setStatusMessage("Ha ha ha, I destroyed you. Better luck next time, puny human!");
    } else {
        cout<<"Wow You win! That's a miracle!"<<endl;
        setStatusMessage("Wow You win! That's a miracle!");
    }
}

/* This is a function that lets the user decide whether he wants to create a random board
 * or input 16 letters to create a board he wants. It will also check if the letters he inputs
 * is valid or not */

bool userSelectBoard (string &boardText){
    bool letterOrNot = true;
    if (!getYesOrNo("Do you want to generate a random board? Type in y or n")){
        while (true){
            boardText = toUpperCase(getLine("Type the 16 letters to appear on the board:"));
            //Checking the length
            if (boardText.length() != 16){
                cout<<"That is not a valid 16-letter board string. Try again."<<endl;
                continue;
            }
            for (char each : boardText){
                if (!isalpha(each)){
                    letterOrNot = false;
                    break;
                }
            }
            if (letterOrNot == false){
                cout<<"That is not a valid 16-letter board string. Try again."<<endl;
                continue;
            } else {
                return true;
            }
        }
    }
    return true;
}

/* This is a function that asks the user to input a word he finds in the boggle. It will check whether
 * the word is valid using the checkWord() function from the Boggle class. If a user types in nothing, it
 * will return false which indicates that the user-input stage is closed. */

bool userInputWord(Boggle& newBoggle, string &newWord){
    setStatusMessage("It's your turn!");
    while (true){
        newWord = toUpperCase(getLine("Type a word (or Enter to stop): "));

        //Checking Enter to stop
        if (newWord == ""){
            return false;
        } else if (!newBoggle.checkWord(newWord)){
            cout<<"You must enter an unfound 4+ letter word from the dictionary."<<endl;
        } else {
            return true;
        }
    }
    cout<<newWord<<endl;
    return true;
}
