/*
* file: Boggle.cpp
* ---------------------
* author: Nahva Techlu and Jeremy Bao
* date: Nov. 6
* This is the Boggle class which can execute the functions needed
* for a boggle game, including checking words human found, recursively
* finding all the words valid in the boggle, setting scores of both sides,
* etc. It uses recursive algorithms to approach complex problems in it.
*/

#include "Boggle.h"
#include <string>
#include <shuffle.h>
#include <bogglegui.h>
#include "lexicon.h"
#include "grid.h"

using namespace std;
using namespace BoggleGUI;

// letters on all 6 sides of every cube
static string CUBES[16] = {
    "AAEEGN", "ABBJOO", "ACHOPS", "AFFKPS",
    "AOOTTW", "CIMOTU", "DEILRX", "DELRVY",
    "DISTTY", "EEGHNW", "EEINSU", "EHRTVW",
    "EIOSST", "ELRTTY", "HIMNQU", "HLNNRZ"
};

// letters on every cube in 5x5 "Big Boggle" version (extension)
static string BIG_BOGGLE_CUBES[25] = {
   "AAAFRS", "AAEEEE", "AAFIRS", "ADENNN", "AEEEEM",
   "AEEGMU", "AEGMNN", "AFIRSY", "BJKQXZ", "CCNSTW",
   "CEIILT", "CEILPT", "CEIPST", "DDLNOR", "DDHNOT",
   "DHHLOR", "DHLNOR", "EIIITT", "EMOTTT", "ENSSSU",
   "FIPRSY", "GORRVW", "HIPRRY", "NOOTUW", "OOOTTU"
};

/* Constructor of buggle. It will pass the dictionary to the Boggle class.
/* If boardText is empty it will create a random board; if it is not, it will
/* create a board as assigned */

Boggle::Boggle(Lexicon& dictionary, string boardText) {
    gameBoard.resize(4,4);

    //Pass the dictionary to the class
    dict = dictionary;

    if (boardText == ""){
        for (int r = 0; r < 4; r++){
            for (int c = 0; c < 4; c++){
                int lineIndex = r * 4 + c;
                string temp = CUBES[lineIndex];
                char letter = temp[randomInteger(0, 5)];
                gameBoard[r][c] = letter;
            }
        }
        shuffle(gameBoard); //Make a random board
    } else {
        for (int r = 0; r < 4; r++){
            for (int c = 0; c < 4; c++){
                gameBoard[r][c] = boardText[r * 4 + c];
            }
        }
    }
}

/* Return the specific letter of the board given the row and col number */

char Boggle::getLetter(const int row, const int col) {
    return gameBoard[row][col];
}

/* Check whether the word is longer than 4 characters, in the dictionary or not,
 * has been used before or not */

bool Boggle::checkWord(string word) {
    if (word.length() < 4){
        return false;
    } else if (!dict.contains(word)){
        return false;
    } else if (usedWords.contains(word)){
        return false;
    } else{
        usedWords.add(word);
        return true;
    }
}

/* Function that checks whether the word from the human is a valid word in the boggle.
/* It uses a recursive approach to check the word */

bool Boggle::humanWordSearch(string word) {
    clearHighlighting();
    checkedLetters.clear();
    wordForCheck = word;
    bool correctOrNot = false;
    for (int r = 0; r < 4; r++){
        for (int c = 0; c < 4; c++){
            setAnimationDelay(100);
            setHighlighted(r, c, true);
            if (wordForCheck[0] == gameBoard[r][c]){
                setHighlighted(r, c, true);
                checkedLetters.add(100 * r + c); // Use 100 * r + C to uniquely represent a letter that has already been used
                string wordSub = wordForCheck.substr(1);
                correctOrNot = recursiveCheck(wordSub, r, c);//The real recursive function
                if (correctOrNot){
                    humanFoundWords.add(word);
                    return true;
                }
            }
            setHighlighted(r, c, false);
        }
    }
    return false;
}

/* This is a helper function we defined. It is the real recursive check function for humanWordSearch */

bool Boggle::recursiveCheck(string &wordCheck, int r, int c){
    if (wordCheck.length() == 0){
        return true;
    } else {
        for (int i = r - 1; i <= r + 1; i++){
            for (int j = c - 1; j <= c + 1; j++){
                if ((gameBoard.inBounds(i, j))&&(!checkedLetters.contains(100 * i + j))) {
                    setAnimationDelay(100);
                    setHighlighted(i, j, true);
                    if (wordCheck[0] == gameBoard[i][j]){
                        checkedLetters.add(100 * i + j);
                        string wordSub2 = wordCheck.substr(1);
                        if(recursiveCheck(wordSub2, i, j)){
                            return true;
                        }
                    }
                    setHighlighted(i, j, false);
                    checkedLetters.remove(100 * i + j);
                }
            }
        }
        return false;
    }
}

Set<string> Boggle::outputHumanFoundWords(){
    return humanFoundWords;
}

/* Calculate the score of human based on the words he found */

int Boggle::getScoreHuman() {
    humanScore += wordForCheck.length() - 3;
    return humanScore;
}

/* Function that finds all the valid words in the boggle.
/* It uses a recursive approach to find all the words */

Set<string> Boggle::computerWordSearch() {
    for (int r = 0; r < 4; r++){
        for (int c = 0; c < 4; c++){
            checkedLetters2.add(r * 100 + c);
            curWord = gameBoard[r][c];
            recursiveComputerCheck(r, c); // Real recursive function
            checkedLetters2.clear();
        }
    }
    computerFoundWords = computerFoundWords - humanFoundWords; //Removing words that human has found
    return computerFoundWords;
}

/* This is a helper function we defined. It is the real recursive function for computerWordSearch*/

void Boggle::recursiveComputerCheck(int r, int c) {

    for (int i = r - 1; i <= r + 1; i++){
        for (int j = c - 1; j <= c + 1; j++){
            if (gameBoard.inBounds(i, j) && !checkedLetters2.contains(100 * i + j)){
                curWord += gameBoard[i][j];
                if ((curWord.length() >= 4) && dict.contains(curWord)){
                    computerFoundWords.add(curWord);
                }
                if (dict.containsPrefix(curWord)){
                    checkedLetters2.add(i * 100 + j);
                    recursiveComputerCheck(i, j);
                }
                curWord = curWord.substr(0, curWord.length()-1);
                checkedLetters2.remove(i * 100 + j);
            }
        }
    }
}

/* Calculate the score of computer based on the words he found */

int Boggle::getScoreComputer() {
    for (string each : computerFoundWords){
        computerScore += each.length() - 3;
    }
    return computerScore;
}

/* Defines the cout function of the Boggle class*/

ostream& operator<<(ostream& out, Boggle& boggle) {
    for (int r = 0; r < boggle.gameBoard.numRows(); r++){
        for (int c = 0; c < boggle.gameBoard.numCols(); c++){
            cout<<boggle.gameBoard[r][c];
        }
        cout<<endl;
    }
    return out;
}
